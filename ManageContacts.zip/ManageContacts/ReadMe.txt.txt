HI Team,

I have create a basic application which will handle create update delete opeation and ofcorse show as well.
Please find below pre requisit for the same.


I have create the same in asp.net core

Prerequisit.

VS2019 with .net core 3.1 installed 
Create a database in SQL server with name "ManageContacts"
Run Query for create table .Location DBQueries folder.

Change connection string from appsetting .json file 
Please contact me if anything required for the same.


Thanks and Regards,
Arihant jain
8983783769